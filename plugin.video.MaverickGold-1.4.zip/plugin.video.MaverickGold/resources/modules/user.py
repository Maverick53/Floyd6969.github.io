import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLk1hdmVyaWNrR29sZA==')

name = b.b64decode('TWF2ZXJpY2sgR29sZA==')

host = b.b64decode('aHR0cDovL2x1bmFydWsub3Jn')
port = b.b64decode('ODA4MA==')