import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLk1hdmVyaWNraXB0dg==')

name = b.b64decode('TWF2ZXJpY2sgSVBUVg==')

host = b.b64decode('aHR0cDovL2x1bmFydWsub3Jn')
port = b.b64decode('ODA4MA==')